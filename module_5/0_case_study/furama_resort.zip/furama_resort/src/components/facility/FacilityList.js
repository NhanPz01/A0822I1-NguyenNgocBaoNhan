import { useEffect, useState } from 'react'
import { NavLink } from 'react-router-dom'
import * as FacilityService from '../../services/FacilityService.js'
import FacilityEditModal from './FacilityEditModal.js'

const FacilityList = () => {
  const [facilities, setFacilities] = useState([])
  const [showEditModal, setShowEditModal] = useState(false)
  const IMG = [
    "https://plus.unsplash.com/premium_photo-1682285212027-6af0d0f70e07?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1887&q=80",
    "https://images.unsplash.com/photo-1566073771259-6a8506099945?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1770&q=80",
    "https://plus.unsplash.com/premium_photo-1682913629540-3857602b540c?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1780&q=80",
    // "https://images.unsplash.com/photo-1615880484746-a134be9a6ecf?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1974&q=80",
    "https://media.architecturaldigest.com/photos/628fb43b978896c06b13b204/16:9/w_2560%2Cc_limit/GettyImages-957245348.jpg",
    "http://www.sanroccovillas.com/photos/mikulina/1.jpg",
    "https://media.istockphoto.com/id/1347784849/photo/scenic-view-of-a-beautiful-landscape-garden-with-a-green-mowed-lawn.jpg?s=612x612&w=0&k=20&c=VU6cE_762lTNwqFeuc1A-JFksy6HcXM35Xq3ox3-Az0="
  ]
  useEffect(() => {
    getAllFacilities()
  }, [facilities])

  const getAllFacilities = async () => {
    const data = await FacilityService.getAll()
    setFacilities(data)
  }

  return (
    <>
      <div className="header">
        <h1>Facility</h1>
      </div>
      {/* Create the navigation bar with some links */}
      <ul className="navigation">
        <li><NavLink to="/">Home</NavLink></li>
        <li><NavLink to="/customer">Customer</NavLink></li>
        <li><NavLink to="/contract">Contract</NavLink></li>
      </ul>
      {/* Create the body with some content */}
      <div className="main">
        <div className='d-flex align-content-start justify-content-center flex-wrap gap-4'>
          {
            facilities.map((facility, index) => {
              let imgURL = ''
              if (index > IMG.length) {
                imgURL = IMG[Math.ceil(index / 2) - 1]
                console.log(Math.ceil(index / 2) - 1)
              } else {
                imgURL = IMG[index]
              }
              
              return (
                <>
                  <div className="card w-25" key={"f-" + facility.id}>
                    <img src={imgURL} className="card-img-top" alt="..." />
                    <div className="card-body d-flex align-items-center flex-wrap">
                      <div className="card-content flex-fill">
                        <h5 className="card-text">{facility.name.toUpperCase()}</h5>
                        <p>Room size {facility.usageArea}m2</p>
                      </div>
                      <div className='card-button'>
                        <button className='btn btn-sm btn-outline-secondary rounded-5 rounded-end-0'>Detail</button>
                        <button className='btn btn-sm btn-outline-primary rounded-0'>Edit</button>
                        <button className='btn btn-sm btn-outline-danger rounded-5 rounded-start-0'>Remove</button>
                      </div>
                    </div>
                  </div>

                </>
              )
            })
          }
          <FacilityEditModal showModal={showEditModal} setShowModal={setShowEditModal}  />

        </div>

        {/* Create the footer with some text */}
      </div>
      <div className="footer">
        <p>© 2023 by NhanPz. All rights reserved.</p>
      </div>
    </>

  )
}

export default FacilityList