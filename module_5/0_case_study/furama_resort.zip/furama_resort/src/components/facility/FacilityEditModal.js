import { Modal } from "react-bootstrap"
import * as Yup from 'yup'
import * as FacilityService from '../../services/FacilityService'

const FacilityEditModal = () => {
  return (
    <>
      
    </>
  )
}

export default FacilityEditModal