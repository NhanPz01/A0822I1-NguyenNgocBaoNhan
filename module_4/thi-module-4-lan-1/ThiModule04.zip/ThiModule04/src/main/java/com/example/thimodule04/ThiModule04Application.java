package com.example.thimodule04;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ThiModule04Application {

    public static void main(String[] args) {
        SpringApplication.run(ThiModule04Application.class, args);
    }

}
